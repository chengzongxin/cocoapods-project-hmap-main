//
//   Created by 彭懂 on 2021/10/8.
//   Abstract: SceneDelegate.h
//  

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

